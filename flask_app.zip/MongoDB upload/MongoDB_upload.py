import pandas as pd
from pymongo import MongoClient

def add_Alliance(df1,df2):
    merged_df = pd.merge(df1, df2, left_on=['year', 'PARTY NAME'], right_on=['Year', 'PARTY NAME'], how='left')
    # Add the 'Alliance' column to the first dataframe
    df1['Alliance'] = merged_df['Alliance']
    df1['Alliance'].fillna('Others', inplace=True)
    return df1

# Function to read Excel file and convert to dictionary
def read_excel_to_dict(file_path,alliance_path):
    df = pd.read_excel(file_path)
    df.columns = [col.strip() for col in df.columns]
    df['logo_url'] = df['PARTY NAME'].apply(lambda x: f"/static/logo?partyName={x}.png")
    df = add_Alliance(df,alliance_path)
    data_dict = df.to_dict(orient='records')
    return data_dict

# Function to upload data to MongoDB
def upload_to_mongodb(data, db_name, collection_name):
    #client = MongoClient('mongodb://localhost:27017/')
    connection_string = "mongodb+srv://scriptuser:gx21SgYInMgLmgN2@cluster.nf36z1t.mongodb.net/"
    # Connect to MongoDB Atlas
    client = MongoClient(connection_string)
    db = client[db_name]
    collection = db[collection_name]
    collection.insert_many(data)
    print("Data uploaded to MongoDB successfully.")

# Main function
def main():
    # Excel file path
    excel_file_path = 'output_2019.xlsx'

    # Database and collection names
    db_name = 'Lokshaba'
    collection_name = 'Lokshaba'

    file_path = "allaince.xlsx"

    alliance= pd.read_excel(file_path)
    # Read Excel file
    df = read_excel_to_dict(excel_file_path,alliance)
    # Upload data to MongoDB
    upload_to_mongodb(df, db_name, collection_name)

if __name__ == "__main__":
    main()
