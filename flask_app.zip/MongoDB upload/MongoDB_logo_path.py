import pymongo
import glob
import os

# Connect to MongoDB
client = pymongo.MongoClient("mongodb://localhost:27017/")
db = client["Lokshaba"]  # Replace 'mydatabase' with your database name

# Create a new collection
collection = db["LogoMaster"]

# Directory containing the images
image_directory = r"D:\xtra\MongoDB upload\logo"  # Replace with the path to your image directory

# Get a list of image files in the directory
image_files = glob.glob(os.path.join(image_directory, "*.png"))  # Change the file extension as needed

# Prepare the list of documents to insert
documents = []
for image_file in image_files:
    # Extract the filename without extension
    filename = os.path.splitext(os.path.basename(image_file))[0]
    
    # Construct the URL
    url = f"/static/logo?partyname={filename}"  # Replace 'example.com' with your domain
    
    # Create a document and add it to the list
    document = {
        "url": url,
        "partyname": filename
    }
    documents.append(document)

# Insert the list of documents into the collection
collection.insert_many(documents)
#print(documents)

print("Images added to the collection.")
